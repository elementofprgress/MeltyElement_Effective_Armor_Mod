This folder is used for packaged World of Tanks modifiers (*.wotmods).  
